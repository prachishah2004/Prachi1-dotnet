using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using UserManagementAPI.Middleware; // Import the namespace for your middleware
using UserManagementAPI.Repositories; // Import the namespace for UserRepository

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Register in-memory data store
builder.Services.AddSingleton<UserRepository>();

// Add logging
builder.Services.AddLogging();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// Configure the middleware pipeline
app.UseExceptionHandlerMiddleware(); // First: Handle exceptions
app.UseAuthenticationMiddleware(); // Next:  Authenticate requests
app.UseMiddleware<LoggingMiddleware>(); // Last:  Log requests/responses

app.UseAuthorization();  //  Authorization comes after Authentication.
app.MapControllers();
app.Run();
