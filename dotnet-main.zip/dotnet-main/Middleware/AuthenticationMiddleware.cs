using Microsoft.AspNetCore.Builder; // Add this
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;
using System.Net;
using System.Text.Json;

namespace UserManagementAPI.Middleware
{
     public static class AuthenticationMiddlewareExtensions  // Make the class static
    {
        public static IApplicationBuilder UseAuthenticationMiddleware(this IApplicationBuilder builder) // Extension method
        {
            return builder.UseMiddleware<AuthenticationMiddleware>();
        }
    }
    public class AuthenticationMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<AuthenticationMiddleware> _logger;

        public AuthenticationMiddleware(RequestDelegate next, ILogger<AuthenticationMiddleware> logger)
        {
            _next = next;
            _logger = logger;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            // Get the Authorization header
            string? authHeader = context.Request.Headers["Authorization"];

            // Check if the header exists and starts with "Bearer "
            if (authHeader != null && authHeader.StartsWith("Bearer "))
            {
                // Extract the token
                string token = authHeader.Substring("Bearer ".Length).Trim();

                // Validate the token (replace with your actual validation logic)
                if (token == "valid_token")
                {
                    // Token is valid, call the next middleware
                    await _next(context);
                    return;
                }
            }

            // Token is invalid or missing, return 401 Unauthorized
            _logger.LogWarning("Authentication failed. Invalid or missing token.");
            context.Response.StatusCode = (int)HttpStatusCode.Unauthorized;
            context.Response.ContentType = "application/json";
            var errorResponse = new { error = "Unauthorized" };
            var json = JsonSerializer.Serialize(errorResponse);
            await context.Response.WriteAsync(json);
        }
    }
}

